S-Function Builder Version to generate .tlc file
